'''
Unit 9 심사문제: 다음 소스 코드를 완성하여 실행 결과대로 문자열이 출력되게 만드세요.

결과
'Python' is a "programming language"
that lets you work quickly
and
integrate systems more effectively.
'''

# Answer:
s = """'Python' is a "programming language"
that lets you work quickly
and
integrate systems more effectively."""